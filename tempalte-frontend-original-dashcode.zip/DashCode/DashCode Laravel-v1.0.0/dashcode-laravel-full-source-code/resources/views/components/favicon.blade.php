{{-- Favicon --}}
<link rel="icon" href="{{ getSettings('favicon') }}" type="image/png">